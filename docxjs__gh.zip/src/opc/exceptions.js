/*
Exceptions specific to python-opc

The base exception class is OpcError.
*/

